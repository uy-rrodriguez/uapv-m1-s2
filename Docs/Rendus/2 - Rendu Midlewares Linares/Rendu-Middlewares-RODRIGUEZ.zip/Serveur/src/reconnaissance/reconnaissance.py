# coding: utf8

import sys, traceback, time
import AppMP3Player

class Reconnaissance:
    def __init__(self):
        pass

    def reconnaitreVoix(self, parole):
        print "Reconnaissance->reconnaitreVoix"

        return "jouer hotel california" #string
