# coding: utf8

import sys, traceback, time
import AppMP3Player
from utils import *


class Reconnaissance:
    def __init__(self):
        pass

    def reconnaitreVoix(self, parole):
        print_("Reconnaissance->reconnaitreVoix")

        return "jouer hotel california" #string
