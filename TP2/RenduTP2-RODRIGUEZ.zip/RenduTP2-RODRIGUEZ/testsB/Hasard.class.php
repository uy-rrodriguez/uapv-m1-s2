<?php

class Hasard {
    // Retourne BANG ou CLIC
    function tirageEntre2Bornes($a, $b) {}
}

?>
